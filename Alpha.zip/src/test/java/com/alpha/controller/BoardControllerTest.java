package com.alpha.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = {com.alpha.config.RootConfig.class,
								 com.alpha.config.ServletConfig.class})
@Log4j
public class BoardControllerTest {
	
	@Setter(onMethod_ = {@Autowired})
	private WebApplicationContext ctx;
	
	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
	}
	
	
//	@Test  // 전체리스트
	public void testListPaging() throws Exception{
		log.info(mockMvc.perform(MockMvcRequestBuilders.get("/board/list")
									.param("pageNum","3")
									.param("amount", "10"))
									.andReturn().getModelAndView().getModelMap());
	}
	
//	@Test  // 상세조회
	public void testGet() throws Exception{
		log.info(mockMvc.perform(MockMvcRequestBuilders
											.get("/board/detail")
											.param("board_id", "58"))
									.andReturn()
									.getModelAndView()
									.getModelMap());
	}
	
//	@Test  // 글 작성
	public void testRegister() throws Exception{
		String resultPage = mockMvc.perform(MockMvcRequestBuilders
											.post("/board/register")
											.param("title", "테스트 새글 제목")
											.param("content", "테스트 새글 내용")
											.param("writer", "2")
											.param("type_id","1")
											.param("authorized","1"))
									.andReturn()
									.getModelAndView()
									.getViewName();
		log.info(resultPage);
	}

//	@Test
//	public void testEdit() throws Exception{
//		String resultPage = 
//				mockMvc.perform(MockMvcRequestBuilders
//											.post("/board/edit")
//											.param("board_id", "61")
//											.param("writer", "2")
//											.param("type_id","1")
//											.param("title", "테스트 수정111")
//											.param("content", "테스트 수정 내용")
//											
//											.param("created_at", "")
//											.param("name", "")
//											.param("type", "")
//											.param("start_date", "")
//											.param("end_date", "")
//											
//											.param("pageNum", "")
//											.param("amount", "")
//											.param("type", "")
//											.param("keyword", "")
//											
//											.param("authorized","1"))
//									.andReturn();
//									.getModelAndView()
//									.getViewName();
//		log.info(resultPage);
//	}

//	@Test // 4. 삭제테스트
	public void testRemove() throws Exception{
		// 삭제전 데이터베이스에 게시물 번호 확인할 것
		String resultPage = mockMvc.perform(MockMvcRequestBuilders
											.post("/board/remove")
											.param("board_id", "61"))
									.andReturn()
									.getModelAndView()
									.getViewName();
		log.info(resultPage);
	}
	
}
















