package com.alpha.service;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alpha.domain.BoardVO;
import com.alpha.domain.Criteria;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {com.alpha.config.RootConfig.class})
@Log4j
public class BoardServiceTest {

	@Autowired
	private BoardService service;
	
//	@Test
	public void testExist() {
		log.info(service);
		assertNotNull(service);
	}
	
//	@Test
	public void testGet() {
		log.info(service.detail(6L));
	}
	
//	@Test
	public void testInsert() {
		
		Date nowDate = new Date();
		
		BoardVO board = new BoardVO();
		board.setWriter("3");
		board.setType_id(3);
		board.setTitle("SERVICE TEST");
		board.setContent("NEW CONTENT");
		
		board.setStart_date(nowDate);
		board.setEnd_date(nowDate);
		board.setAuthorized(1);
		
		service.insert(board);
		
		log.info("INSERT TEST NUMBER : " + board.getBoard_id());
	}
	
//	@Test
	public void testGetList() {
//		service.getList().forEach(board -> log.info(board));
		service.getList(new Criteria(2,10)).forEach(board -> log.info(board));
	}
	
//	@Test
	public void testUpdate() {
		BoardVO board = service.detail(8L);
		if (board == null) {
			return;
		}
		board.setTitle("8번글 수정");
		log.info("update result : " + service.update(board));
	}
	
//	@Test
	public void testDelete() {
		log.info("remove result : " + service.delete(7L));
	}
}











