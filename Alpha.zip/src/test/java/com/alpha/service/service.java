package com.alpha.service;

public interface service {

}
