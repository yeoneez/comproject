package com.alpha.mapper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.context.junit4.SpringRunner;

import com.alpha.domain.BoardVO;
import com.alpha.domain.Criteria;

import lombok.Setter;
import lombok.extern.log4j.Log4j;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {com.alpha.config.RootConfig.class} )
@Log4j
public class BoardMapperTests {
	@Setter(onMethod_ = @Autowired)
	private BoardMapper boardMapper;
	
//	@Test
	public void testGetList() {
		boardMapper.getList().forEach(board -> log.info(board));
	}
	
//	@Test
	public void testInsert() {
		
		Date nowDate = new Date();
//		System.out.println("포맷 지정 전 : " + nowDate);
//		
//        
//		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy년 MM월 dd일"); 
//        	//원하는 데이터 포맷 지정
//		String strNowDate = simpleDateFormat.format(nowDate); 
//        	//지정한 포맷으로 변환 
//		System.out.println("포맷 지정 후 : " + strNowDate);
		
		String str = "2019-09-02 08:10:55";
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date=null;
        try {
			date = format.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		BoardVO board = new BoardVO();
		board.setWriter("1");
		board.setType_id(1);
		board.setTitle("1");
		board.setContent("1");
		
		board.setStart_date(nowDate);
		board.setEnd_date(date);
		board.setAuthorized(1);
		
		boardMapper.insert(board);
		
		
	}
//	@Test
	public void testInsertSelectKey() {
		
		Date nowDate = new Date();
		
		BoardVO board = new BoardVO();
		board.setWriter("3");
		board.setType_id(3);
		board.setTitle("3");
		board.setContent("3");
		
		board.setStart_date(nowDate);
		board.setEnd_date(nowDate);
		board.setAuthorized(1);
		
		boardMapper.insertSelectKey(board);
		
		log.info(board);
	}
	
//	@Test
	public void testRead() {
		BoardVO board = boardMapper.read(7L);
		
		log.info(board);
	}
	
//	@Test
	public void testUpdate() {
		
		Date nowDate = new Date();
		String str = "2024-05-10 15:00:00";
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date=null;
        try {
			date = format.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		BoardVO board = new BoardVO();
		board.setBoard_id(6L);
		board.setWriter("1");
		board.setType_id(3);
		board.setTitle("회식일정입니다");
		board.setContent("참석 시 수당 지급");
		board.setStart_date(date);
		board.setEnd_date(date);
		board.setAuthorized(1);
		
		int count = boardMapper.update(board);
		log.info("UPDATE COUNT: " + count);
	}
	
//	@Test
	public void testDelete() {
		log.info("DELETE COUNT: " + boardMapper.delete(4L));
	}
	
//	@Test
	public void testPaging() {
		Criteria cri = new Criteria();
		
		cri.setPageNum(3);
		cri.setAmount(10);
		
		List<BoardVO> list = boardMapper.getListWithPaging(cri);
		list.forEach(board -> log.info(board));
		
	}
	
}


























