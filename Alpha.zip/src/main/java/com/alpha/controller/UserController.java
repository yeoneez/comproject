package com.alpha.controller;

import com.alpha.domain.EmployeeVO;
import com.alpha.service.FileService;
import com.alpha.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/user/*")
@RequiredArgsConstructor
@Slf4j
public class UserController {
    private final MemberService memberService;
    private final FileService fileService;

    @GetMapping("/profile")
    public String profile(Model model,
                          HttpSession session) {
        if (session.getAttribute("userId") != null) {
            int userId = (Integer) session.getAttribute("userId");
            EmployeeVO employee = memberService.getById(userId);
            model.addAttribute("profile", employee);
            return "user/profile";

        } else {
            return "redirect:/";
        }
    }

    @GetMapping("/update")
    public String update(Model model,
                         HttpSession session) {
        if (session.getAttribute("userId") != null) {
            Integer userId = (Integer) session.getAttribute("userId");
            model.addAttribute("profile", memberService.getById(userId));
            return "user/update";
        }
        return "redirect:/";
    }

    @PostMapping("/update")
    public String update(@RequestParam("image") MultipartFile file,
                         EmployeeVO employeeVO,
                         HttpSession session,
                         Model model) {
        if (session.getAttribute("userId") != null) {
            int userId = (Integer) session.getAttribute("userId");
            employeeVO.setEmp_id(userId);
            if (!file.isEmpty()) {
                employeeVO.setProfileImage(fileService.storeFile(file,userId));
            }
            int result = memberService.updateEmployee(employeeVO);
            if (result == 0) {
                model.addAttribute("error", "오류가 발생했습니다");
            }

        }
        return "redirect:/user/profile";
    }
}
