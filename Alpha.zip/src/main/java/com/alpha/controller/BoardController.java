package com.alpha.controller;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.alpha.domain.BoardVO;
import com.alpha.domain.Criteria;
import com.alpha.domain.PageDTO;
import com.alpha.service.BoardService;

@Controller
@Log4j
@RequestMapping("/board/*")
@AllArgsConstructor
public class BoardController {
	
	private BoardService boardService;
	
	@GetMapping("/list")
	public void board(Criteria cri, Model model) {
	   	log.info("list : " + cri);
	   	model.addAttribute("list", boardService.getList(cri));
	   	int total = boardService.getTotal(cri);
	   	model.addAttribute("pageMaker", new PageDTO(cri, total));
	}
	
	@GetMapping("/register")
	public void register() {
		
	}
	    
	@PostMapping("/register")
	public String register(BoardVO board, RedirectAttributes rttr) {
		log.info("register: " + board);
		boardService.insert(board);
		rttr.addFlashAttribute("result", board.getBoard_id());
//		model.addAttribute("board", boardService.getAll());
		return "redirect:/board/list";
	}
	    
    @GetMapping("/detail")
    public void detail(@RequestParam("board_id") Long board_id, @ModelAttribute("cri") Criteria cri, Model model) {
    	log.info("/detail");
    	model.addAttribute("read", boardService.detail(board_id));
    }

    
    @PostMapping("/edit")
    public String edit(BoardVO board,  @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {
    	log.info("edit: " + board);
    	if (boardService.update(board)) {
    		rttr.addFlashAttribute("result", "success");
    	}
    	
    	return "redirect:/board/list" + cri.getListLink();
    }
    
	
	@RequestMapping(value = "/remove", method = {RequestMethod.GET, RequestMethod.POST})
	public String remove(@RequestParam("board_id") Long board_id, Criteria cri, RedirectAttributes rttr) {
		
		log.info("remove..." + board_id);
		if (boardService.delete(board_id)) {
			rttr.addFlashAttribute("result", "success");
		}
	
		return "redirect:/board/list" + cri.getListLink();
	}
}


















