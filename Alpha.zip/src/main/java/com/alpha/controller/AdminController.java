package com.alpha.controller;

import com.alpha.domain.EmployeeVO;
import com.alpha.service.MemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/admin/*")
@RequiredArgsConstructor
@Slf4j
public class AdminController {
    private final MemberService memberService;
    @GetMapping("/member")
    public void member(HttpSession session, Model model) {
        List<EmployeeVO> employees = memberService.getAllEmployees();
        model.addAttribute("employees", employees);
    }
    @GetMapping("/member/{id}")
    public String getMemberById(@PathVariable int id, Model model) {
        model.addAttribute("profile",  memberService.getById(id));
        model.addAttribute("departments", memberService.getAllDepartments());
        model.addAttribute("positions", memberService.getAllPositions());
        return "admin/member/edit";
    }
    @PostMapping("/member/edit")
    public String editMember(EmployeeVO employee) {
        memberService.manageEmployee(employee);
        return "redirect:/admin/member";
    }
    @GetMapping("/member/register")
    public void register(Model model) {
        model.addAttribute("departments", memberService.getAllDepartments());
        model.addAttribute("positions", memberService.getAllPositions());
    }
    @PostMapping("/member/register")
    public String register(EmployeeVO employee, Model model) {
        log.info(employee.toString());
        int result = memberService.insertEmployee(employee);
        model.addAttribute("result", result);
        return "redirect:/admin/member";
    }
    @PostMapping("/member/delete")
    public String deleteMember(int id, Model model) {
        Integer result = memberService.deleteEmployee(id);
        model.addAttribute("result", result);
        return "redirect:/admin/member";
    }
    
    

}
