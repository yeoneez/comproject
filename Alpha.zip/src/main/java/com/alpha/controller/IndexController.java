package com.alpha.controller;

import com.alpha.domain.EmployeeVO;
import com.alpha.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;

@Controller
public class IndexController {

    @Autowired
    private LoginService loginService;

    @GetMapping("/")
    public String index(HttpSession session) {
        String userEmail = (String) session.getAttribute("userEmail");
        if (userEmail == null) {
        	return "index";
        }
        else {
            return "redirect:/home";
        }
    }

    @PostMapping("/login")
    public String login(@RequestParam("email") String email,
                        @RequestParam("password") String password,
                        Model model, HttpSession session) {
        if (loginService.validateUser(email, password).equals("true")) {
            session.setAttribute("userEmail", email);
            return "redirect:/home";
        }else if (loginService.validateUser(email, password).equals("admin")){
            session.setAttribute("admin", "admin");
            return "redirect:/admin";
        }else if (loginService.validateUser(email, password).equals("retired")) {
            model.addAttribute("error", "퇴사한 직원입니다");
            return "index";
        } else {
            model.addAttribute("error", "입력정보를 확인해주세요");
            return "index";
        }
    }

    @GetMapping("/home")
    public String home(Model model, HttpSession session) {
        String userEmail = (String) session.getAttribute("userEmail");
        if (userEmail != null) {
            EmployeeVO employee = loginService.profile(userEmail);
            model.addAttribute("profile", employee);
            session.setAttribute("userId", employee.getEmp_id());
            return "home";
        }
        return "redirect:/";
    }
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
    @GetMapping("/admin")
    public String admin(HttpSession session) {
        if (session.getAttribute("admin") != null) {
            return "admin";
        }else{
            return "redirect:/";
        }
    }
}