package com.alpha.mapper;

import com.alpha.domain.DepartmentVO;

import java.util.List;

public interface DepartmentMapper {
    List<DepartmentVO> getAll();
}
