package com.alpha.mapper;

import com.alpha.domain.EmployeeVO;

import java.util.List;

public interface EmployeeMapper {
    EmployeeVO getByEmail(String inputEmail);
    EmployeeVO getById(Integer id);
    List<EmployeeVO> getAllByDepartmentId(Integer id);
    List<EmployeeVO> getAll();
    Integer retiredEmployee(Integer id);
    Integer updateEmployee(EmployeeVO employee);
    Integer updateImage(EmployeeVO employee);
    Integer insertEmployee(EmployeeVO employee);
    Integer manageEmployee(EmployeeVO employee);
    Integer deleteEmployee(Integer id);

}
