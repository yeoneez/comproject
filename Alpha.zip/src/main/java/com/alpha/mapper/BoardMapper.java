package com.alpha.mapper;

import com.alpha.domain.BoardVO;
import com.alpha.domain.Criteria;
import com.alpha.domain.EmployeeVO;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface BoardMapper {
	
//	@Select("select * from board where board_id > 0")
//	@Select("SELECT type, writer, title, start_date FROM board B JOIN board_type BT ON B.type_id = BT.type_id")
//	
	public List<BoardVO> getListWithPaging(Criteria cri);
	
	public List<BoardVO> getList();
	
	public void insert(BoardVO board);
	
	public Integer insertSelectKey(BoardVO board);
	
	public BoardVO read(Long board_id);
	
	public int delete(Long board_id);
	
	public int update(BoardVO board_id);
	
	public int getTotalCount(Criteria cri);

//	List<BoardVO> getAll();
}
