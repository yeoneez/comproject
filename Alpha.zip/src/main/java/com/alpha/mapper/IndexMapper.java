package com.alpha.mapper;

import java.util.Date;

public interface IndexMapper {
    Date getCurrentDate();
}
