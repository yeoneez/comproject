package com.alpha.mapper;

import com.alpha.domain.PositionVO;

import java.util.List;

public interface PositionMapper {
    List<PositionVO> getAll();
}
