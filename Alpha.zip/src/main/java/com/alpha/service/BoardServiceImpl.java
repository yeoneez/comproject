package com.alpha.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alpha.domain.BoardVO;
import com.alpha.domain.Criteria;
import com.alpha.mapper.BoardMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class BoardServiceImpl implements BoardService {
	
	@Autowired
    private BoardMapper boardMapper;

//    @Override
//    public List<ListVO> getList(){
//
//    	log.info("getList------");
//    	return boardMapper.getList();
//    }
	
	
	
    @Override
    public void insert(BoardVO board) {
    	log.info("insert------" + board);
//    	boardMapper.insertSelectKey(board);
    	boardMapper.insert(board);
    }
    
    @Override
	public BoardVO detail(Long board_id) {
		log.info("get------" + board_id);
		return boardMapper.read(board_id);
	}
    
    @Override
	public boolean update(BoardVO board) {
		log.info("update------" + board);
		return boardMapper.update(board) == 1;
	}
    
    @Override
	public boolean delete(Long board_id) {
		log.info("delete------" + board_id);
		return boardMapper.delete(board_id) == 1;
	}
    
    @Override
	public List<BoardVO> getList(Criteria cri){

		log.info("get List With Paging : " + cri);
		return boardMapper.getListWithPaging(cri);
	}

	@Override
	public int getTotal(Criteria cri) {
		log.info("total count");
		return boardMapper.getTotalCount(cri);
	}
//	@Override
//	public List<BoardVO> getAll() {
//		
//		return boardMapper.getAll();
//	}

	
	
}










