package com.alpha.service;

import com.alpha.domain.EmployeeVO;
import com.alpha.mapper.EmployeeMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LoginService {
    private final EmployeeMapper employeeMapper;

    public String validateUser(String inputEmail, String inputPassword) {
        EmployeeVO employee = employeeMapper.getByEmail(inputEmail);

        if (employee != null) {
            String password = employee.getPassword();
            if (password.equals(inputPassword)) {
                if (employee.getEmp_id()==1){
                    return "admin";
                }
                if (employeeMapper.retiredEmployee(employee.getEmp_id()) == 0) {
                    return "true";
                }
                return "retired";

            }
        }
        return "false";
    }

    public EmployeeVO profile(String email) {
        return employeeMapper.getByEmail(email);
    }
}

