package com.alpha.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Service
public class FileService {
    public String storeFile(MultipartFile file, Integer id) {
        String fileName = String.format("%d.jpg", id); // Constructing the filename
        try {
            Files.copy(file.getInputStream(), Paths.get("/Users/jihoon/Code/Web/Alpha/src/main/webapp/resources/img/profile/"+fileName), StandardCopyOption.REPLACE_EXISTING);
            return fileName;
        } catch (IOException ex) {
            throw new RuntimeException("Failed to store file " + fileName, ex);
        }
    }
}
