package com.alpha.service;

import com.alpha.domain.DepartmentVO;
import com.alpha.domain.EmployeeVO;
import com.alpha.domain.PositionVO;
import com.alpha.mapper.DepartmentMapper;
import com.alpha.mapper.EmployeeMapper;
import com.alpha.mapper.PositionMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MemberService {
    private final EmployeeMapper employeeMapper;
    private final DepartmentMapper departmentMapper;
    private final PositionMapper positionMapper;

    public EmployeeVO getById(int id) {
        return employeeMapper.getById(id);
    }
    public Integer updateEmployee(EmployeeVO employee) {
        if (employee.getProfileImage().equals("default.jpg")){
            return employeeMapper.updateEmployee(employee);
        }
        return employeeMapper.updateImage(employee);
    }
    public int insertEmployee(EmployeeVO employee) {
        return employeeMapper.insertEmployee(employee);
    }
    public int deleteEmployee(int id) {
        return employeeMapper.deleteEmployee(id);
    }
    public int manageEmployee(EmployeeVO employee) {
        return employeeMapper.manageEmployee(employee);
    }
    public List<EmployeeVO> getAllEmployees() {

        return employeeMapper.getAll();
    }
    public List<EmployeeVO> getByDepartmentId(int departmentId) {
        return  employeeMapper.getAllByDepartmentId(departmentId);
    }
    public List<DepartmentVO> getAllDepartments() {
        return departmentMapper.getAll();
    }
    public List<PositionVO> getAllPositions() {
        return positionMapper.getAll();
    }
}
