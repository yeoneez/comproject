package com.alpha.service;

import java.util.List;

import com.alpha.domain.BoardVO;
import com.alpha.domain.Criteria;
import com.alpha.domain.EmployeeVO;
import com.alpha.mapper.BoardMapper;


public interface BoardService {
	
//	public List<ListVO> getList();
	
	public BoardVO detail(Long board_id);
	
	public void insert(BoardVO board);

	public boolean update(BoardVO board);

	public boolean delete(Long board_id);
	
	public List<BoardVO> getList(Criteria cri);

	public int getTotal(Criteria cri);
	
//	public List<BoardVO> getAll();

    
}
