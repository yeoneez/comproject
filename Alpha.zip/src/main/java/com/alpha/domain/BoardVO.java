package com.alpha.domain;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class BoardVO {
	private Date created_at;
	private String title;
	private String name;
	private String type;
	private String content;
	private String writer;
	private Long board_id;
	private int type_id;
	private int authorized;
	
//	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm")
//	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Seoul")
	private Date start_date;
	private Date end_date;
}
