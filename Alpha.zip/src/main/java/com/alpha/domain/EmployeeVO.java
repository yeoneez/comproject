package com.alpha.domain;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;


@Data
public class EmployeeVO {
    private Integer emp_id;
    private String name;
    private String phone;
    private String email;
    private String password;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate hiredate;
    private Integer department_id;
    private Integer manager_id;
    private Integer position_id;
    private Integer authorized;
    private String profileImage;
    private String department_name;
    private String position_name;
    private String manager_name;
}
