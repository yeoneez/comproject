package com.alpha.domain;

import lombok.Data;

@Data
public class DepartmentVO {
    private int department_id;
    private String department_name;
}
