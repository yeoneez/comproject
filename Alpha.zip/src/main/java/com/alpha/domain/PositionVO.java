package com.alpha.domain;

import lombok.Data;

@Data
public class PositionVO {
    private int position_id;
    private String position_name;
}
